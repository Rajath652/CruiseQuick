package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AutomationTestPractise extends BasePage {
	
	public AutomationTestPractise(WebDriver driver) {
		super(driver);
	}
	
	//Xpath
	
	@FindBy(xpath="//input[@placeholder='Select Cruise Line']")
	public WebElement txtDropdown;
	
	@FindBy(xpath="//button[@data-ody-id='SearchButton']")
	public WebElement btnSeach;
	
	
	
	public void setDropDownValue(String dropdownvalue) {
		txtDropdown.sendKeys(dropdownvalue);
	}
	
	
	
	
	
}
