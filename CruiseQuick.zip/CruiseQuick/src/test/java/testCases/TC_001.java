package testCases;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.AutomationTestPractise;
import pageObjects.HomePage;
import testBase.BaseClass;

public class TC_001 extends BaseClass {

	@Test
	public void verify_lowest_prices() throws InterruptedException, IOException {

		AutomationTestPractise atp = new AutomationTestPractise(driver);

		atp.setDropDownValue("costa");
		atp.txtDropdown.sendKeys(Keys.ENTER);
		atp.btnSeach.click();
		waitFor(4000);
		List<String> li = new ArrayList<>();
		List<WebElement> list = driver.findElements(By.xpath("//span[@class='lowest-sailing-price']"));
		System.out.println("List " + list.size());


		int count1 = Math.min(3, list.size());

		for (int i = 0; i < count1; i++) {
			String liname = list.get(i).getText();
			li.add(liname);
		}
		waitFor(3000);
		System.out.println("first List " + li);
		
		//To open New tab 
		((JavascriptExecutor) driver).executeScript(
				"window.open('https://book.cruisequick.com/swift-test/cruise?advancedsearch=true&siid=1&lang=1&showtrace=true', '_blank');");
		waitFor(3000);
		
		//To switch to new window
		Set<String> windowHandles = driver.getWindowHandles();
		List<String> windows = new ArrayList<>(windowHandles);
		driver.switchTo().window(windows.get(1));
		waitFor(3000);

		atp.setDropDownValue("costa");
		atp.txtDropdown.sendKeys(Keys.ENTER);
		atp.btnSeach.click();
		waitFor(4000);
		
		List<String> li2 = new ArrayList<>();
		List<WebElement> list2 = driver.findElements(By.xpath("//td[@class='text-center ng-star-inserted']//span//span"));

		int count = Math.min(3, list2.size());

		for (int i = 0; i < count; i++) {
			String liname = list2.get(i).getText();
			li2.add(liname);
		}
		waitFor(2000);
		System.out.println("List 2 " + li2);
		
		//Asserting 
		Assert.assertEquals(li, li2, "❌ Values in the two tabs do not match!");
	}
	
	

}
